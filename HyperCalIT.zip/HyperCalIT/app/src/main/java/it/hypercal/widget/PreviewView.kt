package it.hypercal.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import java.time.LocalDate
import java.time.YearMonth

/** Anteprima in miniatura del widget: si aggiorna subito mentre si cambiano le impostazioni. */
class PreviewView(context: Context) : View(context) {

    var monthColor: Int = Settings.ACCENTS[0]
        set(value) { field = value; invalidate() }
    var dotColor: Int = Settings.ACCENTS[0]
        set(value) { field = value; invalidate() }
    var sundayStart: Boolean = false
        set(value) { field = value; invalidate() }
    var dots: Boolean = true
        set(value) { field = value; invalidate() }
    var photoMode: Boolean = false
        set(value) { field = value; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val sampleDots = setOf(2, 5, 9, 12, 16, 21, 24, 28)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w / 2.2f).toInt())
    }

    private fun weekdayRes(d: Int): Int = when (d) {
        1 -> R.string.wd_1
        2 -> R.string.wd_2
        3 -> R.string.wd_3
        4 -> R.string.wd_4
        5 -> R.string.wd_5
        6 -> R.string.wd_6
        else -> R.string.wd_7
    }

    private fun txt(
        c: Canvas, s: String, x: Float, baseline: Float, size: Float, color: Int,
        bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT, serif: Boolean = false
    ) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.textSize = size
        p.color = color
        p.textAlign = align
        p.typeface = when {
            serif -> Typeface.SERIF
            bold -> Typeface.DEFAULT_BOLD
            else -> Typeface.DEFAULT
        }
        c.drawText(s, x, baseline, p)
    }

    private fun fill(c: Canvas, l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = color
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, radius, radius, p)
    }

    override fun onDraw(c: Canvas) {
        val ctx = context
        val w = width.toFloat()
        val h = height.toFloat()
        val u = w / 340f
        val cBg = ctx.getColor(R.color.widget_bg)
        val cPanel = ctx.getColor(R.color.panel_bg)
        val cText = ctx.getColor(R.color.text_primary)
        val cText2 = ctx.getColor(R.color.text_secondary)
        val cWeekend = ctx.getColor(R.color.text_weekend)

        fill(c, 0f, 0f, w, h, 22f * u, cBg)

        val pad = 12f * u
        val gap = 10f * u
        val inner = w - 2f * pad - gap
        val leftW = inner * 1.15f / 2.15f
        val rightW = inner - leftW
        val leftX = pad
        val rightX = pad + leftW + gap

        val today = LocalDate.now()
        val ym = YearMonth.from(today)
        val first = ym.atDay(1)
        val lead = if (sundayStart) first.dayOfWeek.value % 7 else first.dayOfWeek.value - 1
        val weeks = (lead + ym.lengthOfMonth() + 6) / 7

        // titolo del mese e frecce
        txt(c, Fmt.monthTitle(ym), leftX, pad + 11f * u, 12f * u, monthColor, bold = true)
        txt(c, "‹", leftX + leftW - 24f * u, pad + 12f * u, 14f * u, cText2, align = Paint.Align.CENTER)
        txt(c, "›", leftX + leftW - 8f * u, pad + 12f * u, 14f * u, cText2, align = Paint.Align.CENTER)

        // iniziali dei giorni della settimana
        val order = if (sundayStart) intArrayOf(7, 1, 2, 3, 4, 5, 6) else intArrayOf(1, 2, 3, 4, 5, 6, 7)
        val cellW = leftW / 7f
        for (col in 0 until 7) {
            val weekend = if (sundayStart) (col == 0 || col == 6) else (col >= 5)
            txt(
                c, ctx.getString(weekdayRes(order[col])),
                leftX + cellW * (col + 0.5f), pad + 25f * u, 6.5f * u,
                if (weekend) cWeekend else cText2, align = Paint.Align.CENTER
            )
        }

        // griglia dei giorni
        val gridTop = pad + 30f * u
        val gridBottom = h - pad
        val rowH = (gridBottom - gridTop) / weeks
        for (day in 1..ym.lengthOfMonth()) {
            val idx = lead + day - 1
            val row = idx / 7
            val col = idx % 7
            val cx = leftX + cellW * (col + 0.5f)
            val top = gridTop + rowH * row
            val isToday = day == today.dayOfMonth
            val weekend = if (sundayStart) (col == 0 || col == 6) else (col >= 5)
            if (isToday) {
                fill(c, cx - cellW * 0.42f, top + 1f * u, cx + cellW * 0.42f, top + rowH - 1f * u, 5f * u, monthColor)
            }
            val numColor = if (isToday) Fmt.contrastOn(monthColor) else if (weekend) cWeekend else cText
            txt(c, day.toString(), cx, top + rowH * 0.5f, 8f * u, numColor, bold = true, align = Paint.Align.CENTER)
            if (dots && day in sampleDots) {
                p.style = Paint.Style.FILL
                p.shader = null
                p.color = if (isToday) Fmt.contrastOn(monthColor) else dotColor
                c.drawCircle(cx, top + rowH * 0.86f, 1.4f * u, p)
            }
        }

        // pannello di destra
        val pTop = pad
        val pBottom = h - pad
        val tx = rightX + 9f * u
        if (!photoMode) {
            fill(c, rightX, pTop, rightX + rightW, pBottom, 14f * u, cPanel)
            txt(c, Fmt.weekdayFull(today), tx, pTop + 17f * u, 7.5f * u, monthColor, bold = true)
            txt(c, today.dayOfMonth.toString(), tx, pTop + 43f * u, 26f * u, cText, bold = true)
            txt(c, ctx.getString(R.string.preview_event_1), tx, pTop + 57f * u, 6.5f * u, cText2)
            txt(c, ctx.getString(R.string.preview_event_2), tx, pTop + 67f * u, 6.5f * u, cText2)
        } else {
            c.save()
            rect.set(rightX, pTop, rightX + rightW, pBottom)
            path.reset()
            path.addRoundRect(rect, 14f * u, 14f * u, Path.Direction.CW)
            c.clipPath(path)
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(
                rightX, pTop, rightX, pBottom,
                0xFF4F86C6.toInt(), 0xFFEDB783.toInt(), Shader.TileMode.CLAMP
            )
            c.drawRect(rect, p)
            p.shader = null
            p.color = 0xFF8A4B3C.toInt()
            path.reset()
            path.moveTo(rightX, pBottom)
            path.lineTo(rightX, pBottom - 34f * u)
            path.lineTo(rightX + rightW * 0.28f, pBottom - 62f * u)
            path.lineTo(rightX + rightW * 0.50f, pBottom - 40f * u)
            path.lineTo(rightX + rightW * 0.72f, pBottom - 66f * u)
            path.lineTo(rightX + rightW, pBottom - 36f * u)
            path.lineTo(rightX + rightW, pBottom)
            path.close()
            c.drawPath(path, p)
            c.restore()
            txt(c, Fmt.weekdayFull(today), tx, pTop + 17f * u, 7.5f * u, Color.WHITE, bold = true)
            txt(c, today.dayOfMonth.toString(), tx, pTop + 47f * u, 32f * u, Color.WHITE, serif = true)
        }
    }
}
