package it.hypercal.widget

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** Impostazioni: si aprono quando si aggiunge un widget oppure dall'app. */
class ConfigActivity : Activity() {

    private class ColorEntry(val view: LinearLayout, val picker: ColorPickerView)

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private lateinit var current: Settings.Values
    private lateinit var preview: PreviewView
    private lateinit var monthEntry: ColorEntry
    private lateinit var dotEntry: ColorEntry
    private lateinit var weekSeg: Segmented
    private lateinit var countSeg: Segmented
    private lateinit var swDots: Switch
    private lateinit var swPhotoEvents: Switch
    private val photoRadios = ArrayList<RadioButton>()
    private var photoSource = PhotoRepository.SRC_BING
    private lateinit var galleryHolder: LinearLayout
    private var galleryList: List<String> = emptyList()
    private lateinit var calContainer: LinearLayout
    private val calChecks = LinkedHashMap<Long, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        Ui.applySystemBars(this)
        widgetId = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        val ctx = this
        current = Settings.load(ctx)
        val cur = current
        photoSource = cur.photoSource
        galleryList = Settings.galleryUris(ctx)

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 24))

        val heading = TextView(ctx)
        heading.text = getString(R.string.config_title)
        heading.textSize = 30f
        heading.setTypeface(heading.typeface, Typeface.BOLD)
        heading.setTextColor(getColor(R.color.ui_text))
        heading.setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 24), Ui.dp(ctx, 8), Ui.dp(ctx, 4))
        col.addView(heading)

        // --- Anteprima del widget ---
        col.addView(Ui.sectionLabel(ctx, getString(R.string.config_preview)))
        val stage = FrameLayout(ctx)
        val stageBg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF7FA8D8.toInt(), 0xFF3D5A80.toInt())
        )
        stageBg.cornerRadius = Ui.dp(ctx, 24).toFloat()
        stage.background = stageBg
        stage.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 14), Ui.dp(ctx, 14), Ui.dp(ctx, 14))
        preview = PreviewView(ctx)
        preview.monthColor = cur.monthColor
        preview.dotColor = cur.dotColor
        preview.sundayStart = cur.sundayStart
        preview.dots = cur.dots
        stage.addView(preview, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        col.addView(stage)
        val previewSeg = Segmented(
            ctx,
            listOf(getString(R.string.preview_standard), getString(R.string.preview_photo)),
            0
        ) { i -> preview.photoMode = (i == 1) }
        val segLp = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        segLp.topMargin = Ui.dp(ctx, 10)
        col.addView(previewSeg, segLp)

        // --- Colori ---
        col.addView(Ui.sectionLabel(ctx, getString(R.string.config_colors)))
        val colorsCard = Ui.card(ctx)
        monthEntry = colorEntry(
            R.string.config_color_month, R.string.config_color_month_summary, cur.monthColor
        ) { c -> preview.monthColor = c }
        dotEntry = colorEntry(
            R.string.config_color_dots, R.string.config_color_dots_summary, cur.dotColor
        ) { c -> preview.dotColor = c }
        colorsCard.addView(monthEntry.view)
        colorsCard.addView(Ui.divider(ctx))
        colorsCard.addView(dotEntry.view)
        col.addView(colorsCard)

        // --- Calendario ---
        col.addView(Ui.sectionLabel(ctx, getString(R.string.config_calendar)))
        val calCard = Ui.card(ctx)

        val weekBlock = Ui.block(ctx, getString(R.string.config_week_start))
        weekSeg = Segmented(
            ctx,
            listOf(getString(R.string.config_monday), getString(R.string.config_sunday)),
            if (cur.sundayStart) 1 else 0
        ) { i -> preview.sundayStart = (i == 1) }
        val weekLp = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        weekLp.topMargin = Ui.dp(ctx, 10)
        weekBlock.addView(weekSeg, weekLp)
        calCard.addView(weekBlock)
        calCard.addView(Ui.divider(ctx))

        swDots = Ui.switch(ctx, cur.dots)
        swDots.setOnCheckedChangeListener { _, checked -> preview.dots = checked }
        val dotsRow = Ui.row(ctx, getString(R.string.config_dots), null, swDots)
        dotsRow.setOnClickListener { swDots.toggle() }
        calCard.addView(dotsRow)
        calCard.addView(Ui.divider(ctx))

        val countBlock = Ui.block(ctx, getString(R.string.config_event_count))
        countSeg = Segmented(ctx, (1..6).map { it.toString() }, cur.eventCount - 1) { }
        val countLp = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        countLp.topMargin = Ui.dp(ctx, 10)
        countBlock.addView(countSeg, countLp)
        calCard.addView(countBlock)
        col.addView(calCard)

        // --- Foto del giorno ---
        col.addView(Ui.sectionLabel(ctx, getString(R.string.config_photo)))
        val photoCard = Ui.card(ctx)
        val photoLabels = intArrayOf(
            R.string.config_photo_none, R.string.config_photo_bing,
            R.string.config_photo_wiki, R.string.config_photo_gallery
        )
        for (i in photoLabels.indices) {
            val rb = Ui.radio(ctx, i == photoSource)
            photoRadios.add(rb)
            val r = Ui.row(ctx, getString(photoLabels[i]), null, rb)
            r.setOnClickListener { selectPhoto(i) }
            if (i > 0) photoCard.addView(Ui.divider(ctx))
            photoCard.addView(r)
        }
        photoCard.addView(Ui.divider(ctx))
        galleryHolder = LinearLayout(ctx)
        galleryHolder.orientation = LinearLayout.VERTICAL
        photoCard.addView(galleryHolder)
        rebuildGalleryRow()
        photoCard.addView(Ui.divider(ctx))
        swPhotoEvents = Ui.switch(ctx, cur.photoEvents)
        val eventsRow = Ui.row(ctx, getString(R.string.config_photo_events), null, swPhotoEvents)
        eventsRow.setOnClickListener { swPhotoEvents.toggle() }
        photoCard.addView(eventsRow)
        col.addView(photoCard)
        col.addView(note(getString(R.string.config_photo_note)))

        // --- Calendari / account ---
        col.addView(Ui.sectionLabel(ctx, getString(R.string.config_calendars)))
        col.addView(note(getString(R.string.config_calendars_hint)))
        calContainer = Ui.card(ctx)
        val calLp = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        calLp.topMargin = Ui.dp(ctx, 10)
        col.addView(calContainer, calLp)
        populateCalendars()

        // --- Salva (barra fissa in basso) ---
        val scroll = ScrollView(ctx)
        scroll.addView(col)
        val bar = LinearLayout(ctx)
        bar.setBackgroundColor(getColor(R.color.ui_bg))
        bar.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 8), Ui.dp(ctx, 16), Ui.dp(ctx, 12))
        bar.addView(
            Ui.pill(ctx, getString(R.string.config_save), true) { save() },
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        Ui.insets(root)
        setContentView(root)
    }

    private fun note(text: String): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = 13f
        v.setTextColor(getColor(R.color.ui_text2))
        v.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), 0)
        return v
    }

    /** Riga con il colore scelto: toccandola si apre il selettore. */
    private fun colorEntry(
        titleRes: Int, summaryRes: Int, initial: Int, onChange: (Int) -> Unit
    ): ColorEntry {
        val swatch = Swatch(this, initial)
        val picker = ColorPickerView(this, initial) { c ->
            swatch.setSwatchColor(c)
            onChange(c)
        }
        picker.visibility = View.GONE
        picker.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 16))
        val head = Ui.row(this, getString(titleRes), getString(summaryRes), swatch)
        head.setOnClickListener {
            picker.visibility = if (picker.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(head)
        box.addView(picker)
        return ColorEntry(box, picker)
    }

    private fun selectPhoto(i: Int) {
        photoSource = i
        for (k in photoRadios.indices) photoRadios[k].isChecked = (k == i)
    }

    private fun rebuildGalleryRow() {
        galleryHolder.removeAllViews()
        val info = if (galleryList.isEmpty()) getString(R.string.config_photo_count_none)
        else getString(R.string.config_photo_count, galleryList.size)
        val choose = Ui.pill(this, getString(R.string.config_photo_choose), false) { pickPhotos() }
        galleryHolder.addView(
            Ui.row(this, info, getString(R.string.config_photo_rotation), choose)
        )
    }

    private fun pickPhotos() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, 10)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 10 || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val cd = data.clipData
        if (cd != null) {
            for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
        }
        if (uris.isEmpty()) {
            val single = data.data
            if (single != null) uris.add(single)
        }
        val kept = ArrayList<String>()
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                kept.add(u.toString())
            } catch (e: Exception) {
            }
        }
        if (kept.isNotEmpty()) {
            galleryList = kept.sorted()
            selectPhoto(PhotoRepository.SRC_GALLERY)
        }
        rebuildGalleryRow()
    }

    private fun populateCalendars() {
        calContainer.removeAllViews()
        calChecks.clear()

        if (!EventsRepository.hasPermission(this)) {
            val allow = Ui.pill(this, getString(R.string.btn_allow), true) {
                requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 2)
            }
            calContainer.addView(Ui.row(this, getString(R.string.config_need_permission), null, allow))
            return
        }

        val list = EventsRepository.listCalendars(this)
        if (list.isEmpty()) {
            calContainer.addView(Ui.row(this, getString(R.string.config_no_calendars)))
            return
        }

        val selected = current.calendars
        var lastAccount: String? = null
        for (c in list) {
            if (c.account != lastAccount) {
                val header = TextView(this)
                header.text = c.account
                header.textSize = 13f
                header.setTypeface(header.typeface, Typeface.BOLD)
                header.setTextColor(getColor(R.color.ui_text2))
                header.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 2))
                calContainer.addView(header)
                lastAccount = c.account
            }
            val cb = Ui.checkBox(this, selected == null || c.id in selected, c.color)
            calChecks[c.id] = cb
            val r = Ui.row(this, c.name, null, cb)
            r.setOnClickListener { cb.toggle() }
            calContainer.addView(r)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        populateCalendars()
        CalendarWidgetProvider.refreshAll(this)
    }

    private fun save() {
        val calendars: Set<Long>? = when {
            calChecks.isEmpty() -> current.calendars          // elenco non disponibile: non cambiare
            calChecks.values.all { it.isChecked } -> null     // tutti (inclusi quelli futuri)
            else -> calChecks.filterValues { it.isChecked }.keys.toSet()
        }
        Settings.save(
            this,
            Settings.Values(
                monthColor = monthEntry.picker.color,
                dotColor = dotEntry.picker.color,
                sundayStart = weekSeg.current == 1,
                dots = swDots.isChecked,
                eventCount = (countSeg.current + 1).coerceIn(1, 6),
                calendars = calendars,
                photoSource = photoSource,
                photoEvents = swPhotoEvents.isChecked
            )
        )
        Settings.setGalleryUris(this, galleryList)
        PhotoRepository.resetAttempt(this)
        CalendarWidgetProvider.refreshAll(this)
        CalendarWidgetProvider.downloadIfNeeded(applicationContext, null)
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        }
        finish()
    }
}
