package it.hypercal.widget

import android.content.Context
import android.graphics.Color
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

/** Formati di data e ora secondo la lingua di sistema. */
object Fmt {

    fun locale(): Locale = Locale.getDefault()

    fun cap(s: String): String = s.replaceFirstChar { it.titlecase(locale()) }

    fun monthName(ym: YearMonth): String =
        cap(ym.month.getDisplayName(TextStyle.FULL_STANDALONE, locale()))

    fun monthTitle(ym: YearMonth): String = "${monthName(ym)} ${ym.year}"

    fun weekdayFull(d: LocalDate): String =
        cap(d.dayOfWeek.getDisplayName(TextStyle.FULL, locale()))

    fun weekdayShort(d: LocalDate): String =
        d.dayOfWeek.getDisplayName(TextStyle.SHORT, locale())

    /** Ora nel formato scelto dall'utente (12 o 24 ore). */
    fun timeFormat(ctx: Context): java.text.DateFormat =
        android.text.format.DateFormat.getTimeFormat(ctx)

    /** Bianco o quasi nero, a seconda di quale si legge meglio sul colore dato. */
    fun contrastOn(color: Int): Int {
        val lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) +
            0.114 * Color.blue(color)) / 255.0
        return if (lum > 0.65) 0xFF1C1C1E.toInt() else Color.WHITE
    }
}
