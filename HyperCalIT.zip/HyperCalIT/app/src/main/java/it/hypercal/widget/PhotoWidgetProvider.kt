package it.hypercal.widget

/** Variante del widget con la foto del giorno: tutta la logica è in CalendarWidgetProvider. */
class PhotoWidgetProvider : CalendarWidgetProvider()
