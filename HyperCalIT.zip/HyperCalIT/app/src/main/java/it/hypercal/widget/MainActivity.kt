package it.hypercal.widget

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.applySystemBars(this)
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        CalendarWidgetProvider.refreshAll(this)
        build()
    }

    private fun note(text: String): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = 13f
        v.setTextColor(getColor(R.color.ui_text2))
        v.setPadding(Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12), 0)
        return v
    }

    private fun widgetRow(
        mgr: AppWidgetManager, canPin: Boolean, titleRes: Int, summaryRes: Int, provider: Class<*>
    ): View {
        var trailing: View? = null
        if (canPin) {
            trailing = Ui.pill(this, getString(R.string.btn_add), false) {
                mgr.requestPinAppWidget(ComponentName(this, provider), null, null)
            }
        }
        return Ui.row(this, getString(titleRes), getString(summaryRes), trailing)
    }

    private fun build() {
        val ctx = this
        val granted = EventsRepository.hasPermission(ctx)

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 28))

        val title = TextView(ctx)
        title.text = getString(R.string.app_name)
        title.textSize = 30f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(getColor(R.color.ui_text))
        title.setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 28), Ui.dp(ctx, 8), Ui.dp(ctx, 4))
        col.addView(title)

        val sub = TextView(ctx)
        sub.text = getString(R.string.main_subtitle)
        sub.textSize = 14f
        sub.setTextColor(getColor(R.color.ui_text2))
        sub.setPadding(Ui.dp(ctx, 8), 0, Ui.dp(ctx, 8), Ui.dp(ctx, 8))
        col.addView(sub)

        // accesso al calendario + impostazioni
        val card1 = Ui.card(ctx)
        val access: View
        if (granted) {
            val ok = TextView(ctx)
            ok.text = "✓"
            ok.textSize = 20f
            ok.setTypeface(ok.typeface, Typeface.BOLD)
            ok.setTextColor(getColor(R.color.ui_accent))
            access = ok
        } else {
            access = Ui.pill(ctx, getString(R.string.btn_allow), true) {
                requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 1)
            }
        }
        card1.addView(
            Ui.row(
                ctx, getString(R.string.main_calendar_access),
                getString(if (granted) R.string.main_status_ok else R.string.main_status_ko), access
            )
        )
        card1.addView(Ui.divider(ctx))
        val settingsRow = Ui.row(
            ctx, getString(R.string.main_settings), getString(R.string.main_settings_summary),
            Ui.chevron(ctx)
        )
        settingsRow.setOnClickListener { startActivity(Intent(ctx, ConfigActivity::class.java)) }
        card1.addView(settingsRow)
        val lp1 = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        lp1.topMargin = Ui.dp(ctx, 12)
        col.addView(card1, lp1)

        // widget da aggiungere
        col.addView(Ui.sectionLabel(ctx, getString(R.string.main_widgets)))
        val mgr = getSystemService(AppWidgetManager::class.java)
        val canPin = mgr.isRequestPinAppWidgetSupported
        val card2 = Ui.card(ctx)
        card2.addView(
            widgetRow(
                mgr, canPin, R.string.main_widget_month, R.string.main_widget_month_summary,
                CalendarWidgetProvider::class.java
            )
        )
        card2.addView(Ui.divider(ctx))
        card2.addView(
            widgetRow(
                mgr, canPin, R.string.main_widget_photo, R.string.main_widget_photo_summary,
                PhotoWidgetProvider::class.java
            )
        )
        col.addView(card2)
        if (!canPin) col.addView(note(getString(R.string.main_no_pin)))

        col.addView(note(getString(R.string.main_tip)))
        val ver = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            ""
        }
        col.addView(note(getString(R.string.main_version, ver ?: "")))

        val scroll = ScrollView(ctx)
        scroll.addView(col)
        Ui.insets(scroll)
        setContentView(scroll)
    }
}
