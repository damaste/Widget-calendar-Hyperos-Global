package it.hypercal.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.io.FileFilter
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Locale

/**
 * Foto del giorno per il widget con foto.
 * Fonti indipendenti da Xiaomi: Bing (foto del giorno), Wikimedia Commons (immagine del giorno)
 * oppure le foto scelte dall'utente dalla galleria (una al giorno, a rotazione).
 */
object PhotoRepository {

    const val SRC_NONE = 0
    const val SRC_BING = 1
    const val SRC_WIKI = 2
    const val SRC_GALLERY = 3

    private const val UA = "HyperCalendarWidget/2.0 (Android widget)"
    private const val TARGET_SHORT = 480
    private const val MAX_PIXELS = 450_000
    private const val RETRY_MS = 10L * 60 * 1000

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("photo_state", Context.MODE_PRIVATE)

    private fun dir(ctx: Context): File = File(ctx.filesDir, "photos").apply { mkdirs() }

    private fun fileFor(ctx: Context, src: Int, day: String) = File(dir(ctx), "photo_${src}_$day.jpg")

    private fun hasPhotoWidgets(ctx: Context): Boolean {
        val mgr = AppWidgetManager.getInstance(ctx)
        return mgr.getAppWidgetIds(ComponentName(ctx, PhotoWidgetProvider::class.java)).isNotEmpty()
    }

    /** Permette un nuovo tentativo di download subito (es. dopo aver cambiato fonte). */
    private fun bingMarket(): String {
        val l = Fmt.locale()
        return if (l.country.isNotEmpty()) "${l.language}-${l.country}" else "en-US"
    }

    fun resetAttempt(ctx: Context) {
        prefs(ctx).edit().remove("last_attempt").apply()
    }

    /** Serve scaricare la foto di oggi? (solo fonti online, solo se c'è un widget con foto). */
    fun needsDownload(ctx: Context): Boolean {
        val src = Settings.load(ctx).photoSource
        if (src != SRC_BING && src != SRC_WIKI) return false
        if (!hasPhotoWidgets(ctx)) return false
        if (fileFor(ctx, src, LocalDate.now().toString()).exists()) return false
        val last = prefs(ctx).getLong("last_attempt", 0L)
        return System.currentTimeMillis() - last > RETRY_MS
    }

    /** Scarica la foto di oggi. Da chiamare in un thread secondario. */
    fun download(ctx: Context): Boolean {
        val src = Settings.load(ctx).photoSource
        prefs(ctx).edit().putLong("last_attempt", System.currentTimeMillis()).apply()
        val target = fileFor(ctx, src, LocalDate.now().toString())
        val candidates: List<String> = try {
            when (src) {
                SRC_BING -> listOf(bingUrl())
                SRC_WIKI -> wikiUrls()
                else -> emptyList()
            }
        } catch (e: Exception) {
            emptyList()
        }
        for (u in candidates) {
            val tmp = File(target.path + ".tmp")
            try {
                val conn = open(u)
                conn.inputStream.use { ins -> tmp.outputStream().use { out -> ins.copyTo(out) } }
                conn.disconnect()
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(tmp.path, o)
                if (o.outWidth > 0 && tmp.renameTo(target)) {
                    cleanup(ctx, src)
                    return true
                }
            } catch (e: Exception) {
            }
            tmp.delete()
        }
        return false
    }

    /** Bitmap pronta per il widget (ridotta), oppure null se non c'è ancora nessuna foto. */
    fun loadForWidget(ctx: Context): Bitmap? {
        return try {
            val src = Settings.load(ctx).photoSource
            when (src) {
                SRC_BING, SRC_WIKI -> latest(ctx, src)?.let { f -> decode { FileInputStream(f) } }
                SRC_GALLERY -> {
                    val list = Settings.galleryUris(ctx)
                    if (list.isEmpty()) null
                    else {
                        val idx = (LocalDate.now().toEpochDay() % list.size).toInt()
                        val uri = Uri.parse(list[idx])
                        decode { ctx.contentResolver.openInputStream(uri) }
                    }
                }
                else -> null
            }
        } catch (e: Throwable) {
            null
        }
    }

    // ---------- rete ----------

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 20_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        val code = c.responseCode
        if (code != 200) {
            c.disconnect()
            throw IOException("HTTP $code")
        }
        return c
    }

    private fun getText(url: String): String =
        open(url).inputStream.bufferedReader().use { it.readText() }

    private fun bingUrl(): String {
        val j = JSONObject(
            getText("https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=" + bingMarket())
        )
        val u = j.getJSONArray("images").getJSONObject(0).getString("url")
        return if (u.startsWith("http")) u else "https://www.bing.com$u"
    }

    private fun wikiUrls(): List<String> {
        val d = LocalDate.now(ZoneOffset.UTC)
        val api = String.format(
            Locale.US,
            "https://api.wikimedia.org/feed/v1/wikipedia/en/featured/%04d/%02d/%02d",
            d.year, d.monthValue, d.dayOfMonth
        )
        val img = JSONObject(getText(api)).getJSONObject("image")
        val thumb = img.getJSONObject("thumbnail").getString("source")
        val bigger = thumb.replace(Regex("/\\d+px-"), "/960px-")
        return listOf(bigger, thumb).distinct()
    }

    // ---------- file e decodifica ----------

    private fun latest(ctx: Context, src: Int): File? =
        dir(ctx).listFiles(FileFilter { f ->
            f.name.startsWith("photo_${src}_") && f.name.endsWith(".jpg")
        })?.maxByOrNull { it.name }

    private fun cleanup(ctx: Context, src: Int) {
        dir(ctx).listFiles(FileFilter { f ->
            f.name.startsWith("photo_${src}_") && f.name.endsWith(".jpg")
        })?.sortedByDescending { it.name }?.drop(3)?.forEach { it.delete() }
    }

    private fun orientationDegrees(ins: InputStream): Int = try {
        when (
            ExifInterface(ins).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )
        ) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    /** Decodifica ridotta: lato corto ~480-960 px e al massimo ~450k pixel (limite dei widget). */
    private fun decode(opener: () -> InputStream?): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        opener()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val shortSide = minOf(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (shortSide / (sample * 2) >= TARGET_SHORT) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = opener()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val rot = opener()?.use { orientationDegrees(it) } ?: 0
        if (rot != 0) {
            val m = Matrix().apply { postRotate(rot.toFloat()) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val px = bmp.width.toLong() * bmp.height
        if (px > MAX_PIXELS) {
            val f = Math.sqrt(MAX_PIXELS.toDouble() / px)
            bmp = Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * f).toInt().coerceAtLeast(1),
                (bmp.height * f).toInt().coerceAtLeast(1),
                true
            )
        }
        return bmp
    }
}
