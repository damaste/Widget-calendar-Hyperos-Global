package it.hypercal.widget

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.Switch
import android.widget.TextView

/** Componenti dell'interfaccia in stile HyperOS: schede arrotondate, righe, controlli a pillola. */
object Ui {

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(color: Int, radiusPx: Float): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.RECTANGLE
        d.cornerRadius = radiusPx
        d.setColor(color)
        return d
    }

    fun isNight(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    /** Icone della barra di stato e di navigazione chiare o scure secondo il tema. */
    @Suppress("DEPRECATION")
    fun applySystemBars(a: Activity) {
        val decor = a.window.decorView
        val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        var f = decor.systemUiVisibility
        f = if (isNight(a)) (f and light.inv()) else (f or light)
        decor.systemUiVisibility = f
    }

    /** Con la grafica a bordo schermo i contenuti non devono finire sotto le barre di sistema. */
    @Suppress("DEPRECATION")
    fun insets(root: View) {
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(
                ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                ins.systemWindowInsetRight, ins.systemWindowInsetBottom
            )
            ins
        }
    }

    fun sectionLabel(ctx: Context, text: String): TextView {
        val v = TextView(ctx)
        v.text = text
        v.textSize = 13f
        v.setTextColor(ctx.getColor(R.color.ui_text2))
        v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(dp(ctx, 12), dp(ctx, 22), dp(ctx, 12), dp(ctx, 8))
        return v
    }

    fun card(ctx: Context): LinearLayout {
        val v = LinearLayout(ctx)
        v.orientation = LinearLayout.VERTICAL
        v.background = rounded(ctx.getColor(R.color.ui_card), dp(ctx, 22).toFloat())
        return v
    }

    fun divider(ctx: Context): View {
        val v = View(ctx)
        v.setBackgroundColor(ctx.getColor(R.color.ui_divider))
        val lp = LinearLayout.LayoutParams(MATCH, 1)
        lp.marginStart = dp(ctx, 16)
        v.layoutParams = lp
        return v
    }

    fun titleView(ctx: Context, text: String): TextView {
        val v = TextView(ctx)
        v.text = text
        v.textSize = 16f
        v.setTextColor(ctx.getColor(R.color.ui_text))
        return v
    }

    fun summaryView(ctx: Context, text: String): TextView {
        val v = TextView(ctx)
        v.text = text
        v.textSize = 13f
        v.setTextColor(ctx.getColor(R.color.ui_text2))
        v.setPadding(0, dp(ctx, 2), 0, 0)
        return v
    }

    /** Riga: titolo (e descrizione) a sinistra, un controllo facoltativo a destra. */
    fun row(ctx: Context, title: String, summary: String? = null, trailing: View? = null): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(ctx, 16), dp(ctx, 13), dp(ctx, 16), dp(ctx, 13))
        r.minimumHeight = dp(ctx, 56)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(titleView(ctx, title))
        if (summary != null && summary.isNotEmpty()) col.addView(summaryView(ctx, summary))
        r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (trailing != null) {
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.marginStart = dp(ctx, 12)
            r.addView(trailing, lp)
        }
        return r
    }

    /** Blocco verticale (titolo e descrizione) sotto cui aggiungere un controllo a tutta larghezza. */
    fun block(ctx: Context, title: String, summary: String? = null): LinearLayout {
        val b = LinearLayout(ctx)
        b.orientation = LinearLayout.VERTICAL
        b.setPadding(dp(ctx, 16), dp(ctx, 14), dp(ctx, 16), dp(ctx, 14))
        b.addView(titleView(ctx, title))
        if (summary != null && summary.isNotEmpty()) b.addView(summaryView(ctx, summary))
        return b
    }

    private fun tint(ctx: Context, on: Int): ColorStateList = ColorStateList(
        arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
        intArrayOf(on, ctx.getColor(R.color.ui_text2))
    )

    @Suppress("DEPRECATION")
    fun switch(ctx: Context, checked: Boolean): Switch {
        val s = Switch(ctx)
        s.isChecked = checked
        s.trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(ctx.getColor(R.color.ui_accent), ctx.getColor(R.color.ui_track_off))
        )
        s.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        return s
    }

    fun checkBox(ctx: Context, checked: Boolean, color: Int): CheckBox {
        val c = CheckBox(ctx)
        c.isChecked = checked
        c.buttonTintList = tint(ctx, color)
        c.isClickable = false
        c.isFocusable = false
        return c
    }

    fun radio(ctx: Context, checked: Boolean): RadioButton {
        val r = RadioButton(ctx)
        r.isChecked = checked
        r.buttonTintList = tint(ctx, ctx.getColor(R.color.ui_accent))
        r.isClickable = false
        r.isFocusable = false
        return r
    }

    /** Pulsante a pillola: primario (blu pieno) o secondario (sfondo grigio). */
    fun pill(ctx: Context, text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val v = TextView(ctx)
        v.text = text
        v.textSize = 15f
        v.gravity = Gravity.CENTER
        v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(dp(ctx, 18), dp(ctx, 11), dp(ctx, 18), dp(ctx, 11))
        v.setTextColor(if (primary) Color.WHITE else ctx.getColor(R.color.ui_accent))
        v.background = rounded(
            if (primary) ctx.getColor(R.color.ui_accent) else ctx.getColor(R.color.ui_track),
            dp(ctx, 100).toFloat()
        )
        v.setOnClickListener { onClick() }
        return v
    }

    fun chevron(ctx: Context): TextView {
        val v = TextView(ctx)
        v.text = "›"
        v.textSize = 22f
        v.setTextColor(ctx.getColor(R.color.ui_text2))
        return v
    }
}

/** Controllo a segmenti con sfondo a pillola, come la barra Anno / Mese / Settimana / Giorno. */
class Segmented(
    context: Context,
    labels: List<String>,
    initial: Int,
    private val onSelect: (Int) -> Unit
) : LinearLayout(context) {

    var current: Int = initial
        private set
    private val items = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        val pad = Ui.dp(context, 3)
        setPadding(pad, pad, pad, pad)
        background = Ui.rounded(context.getColor(R.color.ui_track), Ui.dp(context, 100).toFloat())
        labels.forEachIndexed { i, label ->
            val tv = TextView(context)
            tv.text = label
            tv.textSize = 14f
            tv.gravity = Gravity.CENTER
            tv.maxLines = 1
            tv.setPadding(Ui.dp(context, 6), Ui.dp(context, 9), Ui.dp(context, 6), Ui.dp(context, 9))
            tv.setOnClickListener { select(i) }
            items.add(tv)
            addView(tv, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        }
        refresh()
    }

    fun select(i: Int) {
        current = i
        refresh()
        onSelect(i)
    }

    private fun refresh() {
        val sel = context.getColor(R.color.ui_segment)
        val on = context.getColor(R.color.ui_text)
        val off = context.getColor(R.color.ui_text2)
        items.forEachIndexed { i, tv ->
            if (i == current) {
                tv.background = Ui.rounded(sel, Ui.dp(context, 100).toFloat())
                tv.setTextColor(on)
                tv.typeface = Typeface.DEFAULT_BOLD
            } else {
                tv.background = null
                tv.setTextColor(off)
                tv.typeface = Typeface.DEFAULT
            }
        }
    }
}

/** Pallino colorato che mostra il colore scelto. */
class Swatch(context: Context, color: Int) : View(context) {

    private val d = GradientDrawable()

    init {
        d.shape = GradientDrawable.OVAL
        d.setStroke(Ui.dp(context, 2), context.getColor(R.color.ui_divider))
        d.setColor(color)
        background = d
    }

    fun setSwatchColor(c: Int) {
        d.setColor(c)
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = Ui.dp(context, 28)
        setMeasuredDimension(s, s)
    }
}
