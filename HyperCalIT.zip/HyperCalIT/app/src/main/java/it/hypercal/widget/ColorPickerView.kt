package it.hypercal.widget

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** Selettore colore: codice esadecimale, colori rapidi e cursori Tonalità / Saturazione / Luminosità. */
class ColorPickerView(
    context: Context,
    initial: Int,
    private val onChange: (Int) -> Unit = {}
) : LinearLayout(context) {

    var color: Int = initial or (0xFF shl 24)
        private set

    private fun px(v: Int) = Ui.dp(context, v)

    private val hsv = FloatArray(3)
    private var updating = false

    private val hexField = EditText(context)
    private val sbH = SeekBar(context)
    private val sbS = SeekBar(context)
    private val sbV = SeekBar(context)

    private val seekListener = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (!fromUser) return
            hsv[0] = sbH.progress.toFloat()
            hsv[1] = sbS.progress / 100f
            hsv[2] = sbV.progress / 100f
            color = Color.HSVToColor(hsv)
            refresh(updateSliders = false, updateHex = true)
            onChange(color)
        }

        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private val presets = intArrayOf(
        0xFF3482FF.toInt(), 0xFFFF8A00.toInt(), 0xFF2DB84C.toInt(), 0xFFF2493B.toInt(),
        0xFF8E5CF6.toInt(), 0xFF12B5B0.toInt(), 0xFFFF4FA3.toInt()
    )

    init {
        orientation = VERTICAL
        Color.colorToHSV(color, hsv)

        // codice esadecimale
        hexField.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
            InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        hexField.filters = arrayOf(InputFilter.LengthFilter(7))
        hexField.setSingleLine()
        hexField.textSize = 16f
        hexField.setTextColor(context.getColor(R.color.ui_text))
        hexField.background = Ui.rounded(context.getColor(R.color.ui_track), Ui.dp(context, 12).toFloat())
        hexField.setPadding(Ui.dp(context, 14), Ui.dp(context, 10), Ui.dp(context, 14), Ui.dp(context, 10))
        hexField.minEms = 6
        val hexLp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
        addView(hexField, hexLp)

        // colori rapidi
        val row = LinearLayout(context)
        row.orientation = HORIZONTAL
        row.setPadding(0, Ui.dp(context, 12), 0, 0)
        for (c in presets) {
            val dot = View(context)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(c)
            dot.background = g
            val lp = LayoutParams(Ui.dp(context, 32), Ui.dp(context, 32))
            lp.marginEnd = Ui.dp(context, 8)
            dot.setOnClickListener { setColor(c) }
            row.addView(dot, lp)
        }
        addView(row)

        // cursori
        addSlider(context.getString(R.string.cp_hue), sbH, 359)
        addSlider(context.getString(R.string.cp_saturation), sbS, 100)
        addSlider(context.getString(R.string.cp_brightness), sbV, 100)
        sbH.background = track(
            intArrayOf(
                0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(), 0xFF00FFFF.toInt(),
                0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
            )
        )

        hexField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (updating) return
                val t = s?.toString()?.trim().orEmpty().removePrefix("#")
                if (t.length == 6 && t.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) {
                    color = Color.parseColor("#$t")
                    Color.colorToHSV(color, hsv)
                    refresh(updateSliders = true, updateHex = false)
                    onChange(color)
                }
            }
        })

        refresh(updateSliders = true, updateHex = true)
    }

    private fun addSlider(label: String, bar: SeekBar, max: Int) {
        val tv = TextView(context)
        tv.text = label
        tv.textSize = 12f
        tv.setTextColor(context.getColor(R.color.ui_text2))
        tv.setPadding(0, px(12), 0, px(2))
        addView(tv)
        bar.max = max
        bar.progressTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        bar.progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        bar.thumbTintList = ColorStateList.valueOf(context.getColor(R.color.ui_text))
        bar.setOnSeekBarChangeListener(seekListener)
        addView(bar, LayoutParams(LayoutParams.MATCH_PARENT, px(30)))
    }

    private fun track(colors: IntArray): Drawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors)
        g.cornerRadius = px(7).toFloat()
        return InsetDrawable(g, 0, px(8), 0, px(8))
    }

    private fun setColor(c: Int) {
        color = c or (0xFF shl 24)
        Color.colorToHSV(color, hsv)
        refresh(updateSliders = true, updateHex = true)
        onChange(color)
    }

    private fun refresh(updateSliders: Boolean, updateHex: Boolean) {
        updating = true
        if (updateSliders) {
            sbH.progress = hsv[0].toInt().coerceIn(0, 359)
            sbS.progress = Math.round(hsv[1] * 100f)
            sbV.progress = Math.round(hsv[2] * 100f)
        }
        if (updateHex) {
            val txt = String.format("#%06X", color and 0xFFFFFF)
            if (hexField.text.toString() != txt) hexField.setText(txt)
        }
        sbS.background = track(
            intArrayOf(
                Color.HSVToColor(floatArrayOf(hsv[0], 0f, hsv[2])),
                Color.HSVToColor(floatArrayOf(hsv[0], 1f, hsv[2]))
            )
        )
        sbV.background = track(
            intArrayOf(
                Color.BLACK,
                Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], 1f))
            )
        )
        updating = false
    }
}
