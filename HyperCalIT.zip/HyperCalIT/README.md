# HyperCalendar Widget

Widget calendario in stile HyperOS per Android (ideato per HyperOS Global, funziona su qualsiasi Android 8+).

- griglia mensile + pannello con giorno e prossimi eventi, oppure variante **mese + foto del giorno**
- lingue: italiano, inglese, francese, spagnolo, russo (segue la lingua di sistema; per-app in Impostazioni › App › Lingua)
- primo giorno della settimana predefinito in base alla lingua; formato 12/24 ore di sistema
- pallino sui giorni con eventi, scelta dei calendari/account, colori personalizzati (mese e pallini)
- foto: Bing, Wikimedia o galleria personale
- tema chiaro/scuro automatico

## Compilare
Android Studio (Build › Build APK) oppure GitHub Actions (artifact CalendarioIT-debug-apk).

## Su HyperOS
Se il widget non si aggiorna: Impostazioni › App › HyperCalendar Widget › Avvio automatico ON e Risparmio energetico › Nessuna restrizione.

## Supporto
Gratuita e open source. Se ti è utile puoi offrirmi un caffè:

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/damaste)
